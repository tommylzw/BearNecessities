﻿using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using Unity.Mathematics;
using UnityEngine;

public class MovementController : MonoBehaviour
{
    Rigidbody2D body;

    float horizontal;
    float vertical;
    float moveLimiter = 0.7f;

    [SerializeField]
    float walkSpeed = 10.0f;
    [SerializeField]
    float runSpeed = 20.0f;
    [SerializeField]
    bool isRunning = false;
    [SerializeField]
    bool isSneaky = false;
    [SerializeField]
    float sneakySpeed = 5.0f;

    [SerializeField]
    float currentSpeed=0;

    [SerializeField]
    public float currentMoveSpeed;

    [SerializeField]
    Animator animator;

    [SerializeField]
    PolygonCollider2D polygonCollider;
    [SerializeField]
    Sprite sprite;

    bool moving = false;
    bool wasMovingVertical = false;
    bool wasMovingHorizontal = false;

    UnityEngine.Vector2 lastMove;
    void Start()
    {
        body = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }
    
    void Update()
    {

        //Check if shift button is pressed to sneaky mode
        if (Input.GetKey(KeyCode.LeftShift))
        {

            isRunning = true;
        }
        else
        {
            isRunning = false;
        }

        //Check if shift button is pressed to sneaky mode
        if (Input.GetKey(KeyCode.LeftControl))
        {

            isSneaky = true;
        }
        else
        {
            isSneaky = false;
        }


        //Select wich type of speed

        if (isSneaky)
        {
            animator.speed = 0.5f;
            currentSpeed = sneakySpeed;
        }
        else if (isRunning)
        {
            animator.speed = 1.5f;
            currentSpeed = runSpeed;
        }
        else
        {
            animator.speed = 1f;
            currentSpeed = walkSpeed;
        }


        currentMoveSpeed = currentSpeed *10* Time.deltaTime;
        if (!GetComponent<PlayerController>().gameController.gameEnd)
        {
            // Gives a value between -1 and 1
            horizontal = Input.GetAxisRaw("Horizontal"); // -1 is left
            vertical = Input.GetAxisRaw("Vertical"); // -1 is down
        }
       

        bool isMovingHorizontal = Mathf.Abs(horizontal) > 0.5f;
        bool isMovingVertical = Mathf.Abs(vertical) > 0.5f;

        if (isMovingVertical && isMovingHorizontal)
        {
            //moving in both directions, prioritize later
            if (wasMovingVertical)
            {
                body.velocity = new UnityEngine.Vector2(horizontal * currentMoveSpeed, 0);
                lastMove = new UnityEngine.Vector2(horizontal, 0f);

               
                
                //Set up animation parameters
                animator.SetFloat("horizontal", horizontal);
                animator.SetFloat("vertical", 0);
                refreshCollider();
            }
            else
            {
                 body.velocity = new UnityEngine.Vector2(0, vertical * currentMoveSpeed);
                lastMove = new UnityEngine.Vector2(0f, vertical);
                animator.SetFloat("vertical", vertical);
                animator.SetFloat("horizontal", 0);
                refreshCollider();

            }
        }
        else if (isMovingHorizontal)
        {
            body.velocity = new UnityEngine.Vector2(horizontal * currentMoveSpeed, 0);
            wasMovingVertical = false;
            lastMove = new UnityEngine.Vector2(horizontal, 0f);

            //Set up animation parameters
            animator.SetFloat("horizontal", horizontal);
            animator.SetFloat("vertical", 0);
            refreshCollider();
        }
        else if (isMovingVertical)
        {
            body.velocity = new UnityEngine.Vector2(0, vertical * currentMoveSpeed);
            wasMovingVertical = true;
            lastMove = new UnityEngine.Vector2(0f, vertical);

            //Set up animation parameters
            animator.SetFloat("vertical", vertical);
            animator.SetFloat("horizontal", 0);
            refreshCollider();
        }
        else
        {
            moving = false;
            body.velocity = UnityEngine.Vector2.zero;
            animator.SetFloat("vertical", vertical);
            animator.SetFloat("horizontal", horizontal);
            refreshCollider();
        }

       

        

       
       
    }

    void FixedUpdate()
    {
        //if (horizontal != 0 && vertical != 0) // Check for diagonal movement
        //{
        //    // limit movement speed diagonally, so you move at 70% speed
        //    horizontal *= moveLimiter;
        //    vertical *= moveLimiter;
        //}
        
        

        //Apply speed
       // body.velocity = new Vector2(horizontal * currentSpeed, vertical * currentSpeed);
    }

    public float getBodySpeed()
    {

        float x =math.abs( body.velocity.x);
        float y =math.abs( body.velocity.y);
        if (x > y)
            return x;
        else
            return y;
    }

    void refreshCollider()
    {
        polygonCollider = GetComponent<PolygonCollider2D>();
        sprite = GetComponent<SpriteRenderer>().sprite;
        //for (int i = 0; i < polygonCollider.pathCount; i++) polygonCollider .SetPath(i, null);
        polygonCollider.pathCount = sprite.GetPhysicsShapeCount();

        List<UnityEngine.Vector2> path = new List<UnityEngine.Vector2>();
        for (int i = 0; i < polygonCollider.pathCount; i++)
        {
            path.Clear();
            sprite.GetPhysicsShape(i, path);
            polygonCollider.SetPath(i, path.ToArray());
        }
    }


}
