﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;


enum NPCState { WARD = 0, SEARCH = 1, SPOTTED = 2 };
public class NPCController : MonoBehaviour
{

    
    //WARDER
    public float wanderRadius;
    public float wanderTimer;
   
    [SerializeField]
    private NavMeshAgent agent;
    [SerializeField]
    private float timer;
    [SerializeField]
    float warderSpeed;

    //SEARCH
    public float searchTime;
    [SerializeField]
    private float searchTimer;

    [SerializeField]
    float searchSpeed;


    //HUNT
    [SerializeField]
    private Transform target;
    [SerializeField]
    float huntSpeed;

    [SerializeField]
    NPCState currentState = NPCState.WARD;

    [SerializeField]
    NPCGroupController nPCGroupController;

    [SerializeField]
    Animator animator;

    [SerializeField]
    GameObject bubbleSpeech;

    // Use this for initialization
    void OnEnable()
    {
        agent = GetComponent<NavMeshAgent>();
        timer = wanderTimer;

        agent.updateRotation = false;
        agent.updateUpAxis = false;

        nPCGroupController = GetComponentInParent<NPCGroupController>();

        animator = GetComponent<Animator>();
       
            
    }

    // Update is called once per frame
    void Update()
    {

        transform.GetChild(1).LookAt(agent.destination);

        animator.SetFloat("Horizontal", agent.velocity.x);
        animator.SetFloat("Vertical", agent.velocity.y);
        animator.SetFloat("Magnitud", agent.velocity.magnitude);

        switch (currentState)
        {
            
            
            case NPCState.WARD://WARD
                agent.speed = warderSpeed;
                timer += Time.deltaTime;

                if (timer >= wanderTimer)
                {
                    Vector3 newPos = RandomNavSphere(nPCGroupController.gatherPoint, wanderRadius, -1);
                    agent.SetDestination(newPos);
                    timer = 0;
                }
                break;

            case NPCState.SEARCH://SEARCH

                agent.speed = searchSpeed;
                searchTimer += Time.deltaTime;

                if (searchTimer >= searchTime)
                {
                    currentState = NPCState.WARD;
                    searchTimer = 0;
                    nPCGroupController.restartSearchPoint();
                }

                timer += Time.deltaTime;

                if (timer >= wanderTimer)
                {
                    Vector3 newPos = RandomNavSphere(nPCGroupController.searchPoint, wanderRadius, -1);
                    agent.SetDestination(newPos);
                    timer = 0;
                }
                break;

            case NPCState.SPOTTED://HUNT

                agent.speed = huntSpeed;
                agent.SetDestination(target.position);
                break;

        }
        
    }

    public static Vector3 RandomNavSphere(Vector3 origin, float dist, int layermask)
    {
        Vector3 randDirection = Random.insideUnitSphere * dist;

        randDirection += origin;

        NavMeshHit navHit;

        NavMesh.SamplePosition(randDirection, out navHit, dist, layermask);

        return navHit.position;
    }

    //Player spotted by sound, lets search in group
    public void search(Vector3 pos)
    {

        currentState = NPCState.SEARCH;
        activeBubble();
        nPCGroupController.searchInArea(pos);
    }

    //Player found, hunt it
    public void hunt(Transform player)
    {
        currentState = NPCState.SPOTTED;

        
        if (!bubbleSpeech.activeInHierarchy)
        {
            print("activated bubble");
            // StopAllCoroutines();
            bubbleSpeech.SetActive(true);
            StartCoroutine(StartCountdown());

        }
        target = player;
       

    }

    public void activeBubble()
    {

        
        if (!bubbleSpeech.activeInHierarchy)
        {
            bubbleSpeech.SetActive(true);
            print("activated bubble");
            //StopAllCoroutines();
           
            StartCoroutine(StartCountdown());
        }
       
    }


    float currCountdownValue;
    public IEnumerator StartCountdown(float countdownValue = 4)
    {
        currCountdownValue = countdownValue;
        while (currCountdownValue > 0)
        {

            //print(currCountdownValue);
            yield return new WaitForSeconds(1.0f);
            currCountdownValue--;
        }

        bubbleSpeech.SetActive(false);
    }

}
