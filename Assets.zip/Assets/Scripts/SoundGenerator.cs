﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundGenerator : MonoBehaviour
{
    [SerializeField]
    MovementController movementController;
    [SerializeField]
    CircleCollider2D circleCollider;
    // Start is called before the first frame update
    void Start()
    {
        movementController = transform.GetComponentInParent<MovementController>();
        circleCollider = transform.GetComponent<CircleCollider2D>();
    }

    int counter = 0;
    int updateMaxCount = 10;
    // Update is called once per frame
    void FixedUpdate()
    {
        counter++;
        if (counter > updateMaxCount)
        {
            circleCollider.radius = movementController.getBodySpeed();
            counter = 0;
        }
      
    }


    private void OnTriggerEnter2D(Collider2D other)
    {

        if (other.tag == "NPC")
        {
            other.GetComponent<NPCController>().search(transform.position);
            print("Bear sound heard!!!!");
        }
    }
}
