﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    [SerializeField]
    GameObject gameOverPanel;

    [SerializeField]
    Text scoreText;

    [SerializeField]
    PlayerController playerController;

    public bool gameEnd=false;
    public void gameOver()
    {
        gameOverPanel.SetActive(true);
        gameEnd = true;
    }

    public void openMenu()
    {
        SceneManager.LoadScene(0);
    }

    private void Update()
    {
        scoreText.text = playerController.getPoints().ToString();
    }
}
