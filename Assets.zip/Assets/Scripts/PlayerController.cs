﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField]
   public  bool isHide = false;
    [SerializeField]
    public GameController gameController;

    [SerializeField]
    int pointsEarned = 0;

    // Start is called before the first frame update
    void Start()
    {

        gameController = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void hidePlayer()
    {
        isHide = true;
    }

    public void unHidePlayer()
    {
        isHide = false;
    }

    public void addPoints(int numberToAdd)
    {
        pointsEarned += numberToAdd;

        print("Earned points: " + numberToAdd);
    }

    public int getPoints()
    {
        return pointsEarned;
    }

    void OnCollisionEnter2D(Collision2D col)
    {

        if (col.transform.tag == "Fruit")
        {
            addPoints(col.transform.GetComponent<Fruit>().getPoints());
            col.transform.GetComponent<Fruit>().delete();
            Destroy(col.transform.gameObject);
        }
            
    }
}
