﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.AI;

public class NPCGroupController : MonoBehaviour
{
    [SerializeField]
    List<NPCController> NPCs;

    [SerializeField]
    public Vector3 gatherPoint;

    [SerializeField]
    public Vector3 searchPoint;

    [SerializeField]
    List<GameObject> fruitsPrefabs;

    [SerializeField]
    List<GameObject> fruitSpawned;


    [SerializeField]
    int maxNumberSpawnedFruits = 5;

    [SerializeField]
    float checkTimeToSpawn = 30;

    [SerializeField]
    int fruitSpawnDistance = 10;


    // Start is called before the first frame update

    private void Start()
    {
        gatherPoint = transform.position;
       NPCs= GetComponentsInChildren<NPCController>().ToList<NPCController>();

        StartCoroutine(spawnFruit(checkTimeToSpawn));
    }

    void huntPlayer(Transform player)
    {
        foreach(NPCController temp in NPCs)
        {
            temp.hunt(player);
        }
    }

    public void searchInArea(Vector3 pos)
    {
        searchPoint = pos;
    }

    public void restartSearchPoint()
    {
        searchPoint = gatherPoint;
    }

    private void Update()
    {
        
    }

    public void spawnFruit()
    {
        GameObject newFruit = Instantiate<GameObject>(fruitsPrefabs[Random.Range(0,fruitsPrefabs.Count)], this.transform);
        newFruit.transform.position = RandomNavSphere(gatherPoint, fruitSpawnDistance, -1);
        newFruit.GetComponent<Fruit>().setNPCGroupController(this);
        fruitSpawned.Add(newFruit);
    }

    public void removeFruit(GameObject fruitToRemove)
    {
        fruitSpawned.Remove(fruitToRemove);
    }

    public static Vector3 RandomNavSphere(Vector3 origin, float dist, int layermask)
    {
        Vector3 randDirection = Random.insideUnitSphere * dist;

        randDirection += origin;

        NavMeshHit navHit;

        NavMesh.SamplePosition(randDirection, out navHit, dist, layermask);

        return navHit.position;
    }



    
    public IEnumerator spawnFruit(float checkTimeToSpawn)
    {
        
        while (true)
        {

            if (fruitSpawned.Count < maxNumberSpawnedFruits)
                spawnFruit();

            yield return new WaitForSeconds(checkTimeToSpawn);
           
        }

      
    }

}
