﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fruit : MonoBehaviour
{
    [SerializeField]
    private int points;

    [SerializeField]
    private NPCGroupController groupController;


    public void delete()
    {
        groupController.removeFruit(this.gameObject);
    }
    public void setNPCGroupController(NPCGroupController temp)
    {
        groupController = temp;
    }

    public int getPoints()
    {
        return points;
    }
}
